package pt.iscte.poo.sokobanstarter;

public class Main {
	public static void main(String[] args) throws Exception {
		GameEngine.getInstance().start();
				
	}
}
